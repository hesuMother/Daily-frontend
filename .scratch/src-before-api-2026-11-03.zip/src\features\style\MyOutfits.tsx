import { useState } from "react";
import { Trash2 } from "lucide-react";
import type { DailyProduct } from "../../app/App";
import { errorMessage } from "../../shared/api/storage";

// 로그인한 회원이 직접 올린 코디 목록. 삭제 권한은 서버(api)에서 한 번 더 확인한다.
export function MyOutfits({
  outfits,
  onDelete,
  onSelect,
}: {
  outfits: DailyProduct[];
  onSelect: (outfit: DailyProduct) => void;
  onDelete: (outfitId: number) => Promise<void>;
}) {
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [error, setError] = useState("");

  const handleDelete = async (outfit: DailyProduct) => {
    if (!window.confirm("정말 삭제하시겠습니까?")) return;
    setError("");
    setDeletingId(outfit.id);
    try {
      await onDelete(outfit.id);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setDeletingId(null);
    }
  };

  if (outfits.length === 0) {
    return <p className="pt-20 text-center text-[14px] text-[#8c857d]">아직 올린 코디가 없어요</p>;
  }

  return (
    <div>
      {error && <p className="mb-4 text-[13px] text-[#b34b42]">{error}</p>}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {outfits.map((outfit) => (
          <div key={outfit.id}>
            <div className="relative aspect-[3/4] overflow-hidden bg-[#efede9]">
              <button type="button" onClick={() => onSelect(outfit)} aria-label={`${outfit.name} 보기`} className="block h-full w-full">
                {outfit.img ? (
                  <img src={outfit.img} alt="" className="h-full w-full object-cover" />
                ) : (
                  <span className="flex h-full w-full items-center justify-center text-[12px] text-[#b5aea5]">이미지 없음</span>
                )}
              </button>
              {outfit.style && (
                <span className="absolute left-2.5 top-2.5 bg-black/55 px-2 py-0.5 text-[9px] font-bold tracking-widest text-white backdrop-blur-sm">
                  {outfit.style}
                </span>
              )}
              <button
                type="button"
                onClick={() => void handleDelete(outfit)}
                disabled={deletingId === outfit.id}
                className="absolute right-2.5 top-2.5 flex items-center gap-1 bg-white/90 px-2 py-1.5 text-[11px] font-bold text-[#b34b42] transition-colors hover:bg-white disabled:opacity-50"
                aria-label={`${outfit.name} 삭제`}
              >
                <Trash2 size={12} /> {deletingId === outfit.id ? "삭제 중..." : "삭제"}
              </button>
            </div>
            <p className="mt-3 truncate text-[13px]">{outfit.name}</p>
            <p className="mt-1 text-[12px] text-[#8c857d]">연결 상품 {outfit.productIds.length}개</p>
          </div>
        ))}
      </div>
    </div>
  );
}
