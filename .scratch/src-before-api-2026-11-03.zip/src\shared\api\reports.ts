import { now, nextId, saveTable, table, type ReportCategoryRow, type ReportRow } from "./db";
import { ApiError, requireSessionUserId } from "./storage";

// 관리자 화면용: 신고에 분류명과 신고자 이름을 붙인 형태
export interface ReportView extends ReportRow {
  report_category_name: string;
  reporter_username: string;
}

function requireAdmin() {
  const userId = requireSessionUserId();
  if (table("users").find((u) => u.user_id === userId)?.role !== "admin") throw new ApiError("관리자만 사용할 수 있습니다.");
}

export async function fetchReportCategories(): Promise<ReportCategoryRow[]> {
  return table("report_categories");
}

export async function createReport(input: { reason: string; description: string; report_category_id: number }): Promise<ReportRow> {
  const reporter_id = requireSessionUserId();
  const reason = input.reason.trim();
  if (!reason) throw new ApiError("신고 사유를 입력해주세요.");
  if (!table("report_categories").some((c) => c.report_category_id === input.report_category_id)) {
    throw new ApiError("신고 분류를 선택해주세요.");
  }

  const rows = table("reports");
  const row: ReportRow = {
    report_id: nextId(rows, (r) => r.report_id),
    reason,
    description: input.description.trim(),
    report_category_id: input.report_category_id,
    reporter_id,
    complete: false,
    completed_at: null,
    created_at: now(),
  };
  saveTable("reports", [...rows, row]);
  return row;
}

export async function fetchReports(): Promise<ReportView[]> {
  requireAdmin();
  const categories = table("report_categories");
  const users = table("users");
  return table("reports")
    .map((r) => ({
      ...r,
      report_category_name: categories.find((c) => c.report_category_id === r.report_category_id)?.report_category_name ?? "기타",
      reporter_username: users.find((u) => u.user_id === r.reporter_id)?.username ?? "탈퇴한 회원",
    }))
    .sort((a, b) => b.report_id - a.report_id);
}

export async function completeReport(reportId: number): Promise<void> {
  requireAdmin();
  saveTable("reports", table("reports").map((r) => (r.report_id === reportId ? { ...r, complete: true, completed_at: now() } : r)));
}
