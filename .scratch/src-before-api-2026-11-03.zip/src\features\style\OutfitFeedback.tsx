import { useEffect, useState } from "react";
import { Flag, Star, X } from "lucide-react";
import type { ReportCategoryRow } from "../../shared/api/db";
import { fetchOutfitRating, rateOutfit, type OutfitRating } from "../../shared/api/outfits";
import { createReport, fetchReportCategories } from "../../shared/api/reports";
import { errorMessage } from "../../shared/api/storage";

// ─── 신고 모달 ────────────────────────────────────────────────────────────────

function ReportModal({ outfitId, outfitName, onClose }: { outfitId: number; outfitName: string; onClose: () => void }) {
  const [categories, setCategories] = useState<ReportCategoryRow[]>([]);
  const [categoryId, setCategoryId] = useState<number | null>(null);
  const [reason, setReason] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);

  useEffect(() => {
    let active = true;
    fetchReportCategories().then((rows) => { if (active) setCategories(rows); });
    return () => { active = false; };
  }, []);

  const handleSubmit = async () => {
    if (categoryId === null) { setError("신고 분류를 선택해주세요."); return; }
    try {
      // reports 테이블에 신고 대상 컬럼이 없어 대상 코디를 설명 앞에 적어둔다.
      await createReport({
        reason,
        description: `[코디 #${outfitId} ${outfitName}] ${description.trim()}`,
        report_category_id: categoryId,
      });
      setDone(true);
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-5 text-left" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>
      <div className="absolute inset-0 bg-black/55" onClick={onClose} />
      <div className="relative w-full max-w-[400px] bg-background p-6" style={{ boxShadow: "0 24px 64px rgba(0,0,0,0.25)" }}>
        <button type="button" onClick={onClose} aria-label="닫기" className="absolute right-4 top-4 text-muted-foreground transition-colors hover:text-foreground">
          <X size={17} />
        </button>

        {done ? (
          <div className="py-4 text-center">
            <p className="mb-2 text-[16px] font-bold">신고가 접수되었습니다</p>
            <p className="mb-6 text-[12px] leading-relaxed text-muted-foreground">검토 후 필요한 조치를 진행하겠습니다.</p>
            <button type="button" onClick={onClose} className="w-full bg-primary py-3 text-[13px] font-bold text-primary-foreground">확인</button>
          </div>
        ) : (
          <>
            <p className="mb-1 text-[16px] font-bold">코디 신고</p>
            <p className="mb-5 truncate text-[12px] text-muted-foreground">{outfitName}</p>

            <p className="mb-2 text-[12px] font-medium text-muted-foreground">신고 분류</p>
            <div className="mb-4 flex flex-wrap gap-1.5">
              {categories.map((c) => (
                <button
                  key={c.report_category_id}
                  type="button"
                  onClick={() => { setCategoryId(c.report_category_id); setError(""); }}
                  className={`border px-3 py-1.5 text-[12px] transition-colors ${
                    categoryId === c.report_category_id
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border text-muted-foreground hover:border-primary hover:text-foreground"
                  }`}
                >
                  {c.report_category_name}
                </button>
              ))}
            </div>

            <label htmlFor="report-reason" className="mb-1.5 block text-[12px] font-medium text-muted-foreground">신고 사유</label>
            <input
              id="report-reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              maxLength={60}
              placeholder="한 줄로 요약해주세요"
              className="mb-4 w-full border border-border bg-background px-3 py-2.5 text-[13px] outline-none transition-colors focus:border-primary"
            />

            <label htmlFor="report-description" className="mb-1.5 block text-[12px] font-medium text-muted-foreground">상세 내용 (선택)</label>
            <textarea
              id="report-description"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={300}
              className="w-full resize-none border border-border bg-background px-3 py-2.5 text-[13px] outline-none transition-colors focus:border-primary"
            />

            {error && <p role="alert" className="mt-3 text-[12px] text-destructive">{error}</p>}

            <button type="button" onClick={handleSubmit} className="mt-5 w-full bg-primary py-3 text-[13px] font-bold text-primary-foreground transition-opacity hover:opacity-90">
              신고하기
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ─── 별점 + 신고 ──────────────────────────────────────────────────────────────

export function OutfitFeedback({ outfitId, outfitName }: { outfitId: number; outfitName: string }) {
  const [rating, setRating] = useState<OutfitRating>({ average: 0, count: 0, myStars: null });
  const [hovered, setHovered] = useState(0);
  const [error, setError] = useState("");
  const [reportOpen, setReportOpen] = useState(false);

  useEffect(() => {
    let active = true;
    fetchOutfitRating(outfitId).then((r) => { if (active) setRating(r); });
    return () => { active = false; };
  }, [outfitId]);

  const handleRate = async (stars: number) => {
    try {
      setRating(await rateOutfit(outfitId, stars));
      setError("");
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  const filled = hovered || rating.myStars || 0;

  return (
    <div className="border border-border p-4 text-left">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="mb-1.5 text-[11px] font-bold tracking-wider text-muted-foreground">
            {rating.myStars ? `내 별점 ${rating.myStars}점` : "이 코디 어때요?"}
          </p>
          <div className="flex gap-0.5" onMouseLeave={() => setHovered(0)}>
            {[1, 2, 3, 4, 5].map((stars) => (
              <button
                key={stars}
                type="button"
                aria-label={`별점 ${stars}점`}
                onMouseEnter={() => setHovered(stars)}
                onClick={() => handleRate(stars)}
                className="p-0.5"
              >
                <Star size={20} className={stars <= filled ? "fill-accent text-accent" : "text-border"} />
              </button>
            ))}
          </div>
        </div>
        <div className="text-right">
          <p className="text-[18px] font-bold leading-none">{rating.count ? rating.average.toFixed(1) : "—"}</p>
          <p className="mt-1 text-[11px] text-muted-foreground">{rating.count}명 평가</p>
        </div>
      </div>

      {error && <p role="alert" className="mt-2 text-[12px] text-destructive">{error}</p>}

      <button
        type="button"
        onClick={() => setReportOpen(true)}
        className="mt-3 flex items-center gap-1 text-[11px] text-muted-foreground transition-colors hover:text-foreground"
      >
        <Flag size={11} /> 이 코디 신고하기
      </button>

      {reportOpen && <ReportModal outfitId={outfitId} outfitName={outfitName} onClose={() => setReportOpen(false)} />}
    </div>
  );
}
