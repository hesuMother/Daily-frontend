import { useEffect, useRef, useState } from "react";
import { ChevronRight, Heart, X } from "lucide-react";
import type { DailyProduct, Product, ShopPrice } from "../../app/App";
import { OutfitFeedback } from "./OutfitFeedback";
import { clickable, useEscapeKey } from "../../shared/a11y";
import { bodyInfoError, fetchOutfitRating } from "../../shared/api/outfits";
import { errorMessage } from "../../shared/api/storage";
import { uploadImage } from "../../shared/api/userData";

const SEASONS = ["봄", "여름", "가을", "겨울"];

// 시드 코디는 계절이 SS·FW 같은 시즌 코드로 저장돼 있어, 필터에서는 계절 이름으로 풀어서 비교한다.
const SEASON_CODES: Record<string, string[]> = { SS: ["봄", "여름"], FW: ["가을", "겨울"], AW: ["가을", "겨울"] };
const seasonsOf = (outfit: DailyProduct) => outfit.seasons.flatMap((s) => SEASON_CODES[s] ?? [s]);

const bodyInfo = (item: DailyProduct) =>
  [item.height && `${item.height}cm`, item.weight && `${item.weight}kg`].filter(Boolean).join(" · ");

// ─── 코디 피드 업로드 모달 ────────────────────────────────────────────────────

function OutfitFeedUploadModal({
  styles,
  catalogProducts,
  getShopPrices,
  onClose,
  onSubmit,
}: {
  styles: string[];
  catalogProducts: Product[];
  getShopPrices: (product: Product) => ShopPrice[];
  onClose: () => void;
  onSubmit: (o: DailyProduct) => Promise<void>;
}) {
  const [img, setImg] = useState("");
  const [title, setTitle] = useState("");
  const [height, setHeight] = useState("");
  const [weight, setWeight] = useState("");
  const [seasons, setSeasons] = useState<string[]>([]);
  const [style, setStyle] = useState("");
  const [productIds, setProductIds] = useState<number[]>([]);
  const [desc, setDesc] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  useEscapeKey(onClose);

  const attachImage = async (file?: File) => {
    if (!file || !file.type.startsWith("image/")) return;
    try {
      setImg(await uploadImage(file));
      setErrors((er) => ({ ...er, img: "" }));
    } catch (err) {
      setErrors((er) => ({ ...er, submit: errorMessage(err) }));
    }
  };

  // 상품은 카테고리와 상관없이 원하는 만큼 고를 수 있다. 다시 누르면 선택이 풀린다.
  const toggleProduct = (id: number) => {
    setErrors((er) => ({ ...er, products: "" }));
    setProductIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const handleSubmit = async () => {
    const e: Record<string, string> = {};
    if (!title.trim()) e.title = "코디 제목을 입력해주세요.";
    if (!img) e.img = "사진을 추가해주세요.";
    if (!style) e.style = "스타일 태그를 선택해주세요.";
    if (productIds.length === 0) e.products = "상품을 1개 이상 선택해주세요.";
    const bodyError = bodyInfoError(height, weight);
    if (bodyError) e.body = bodyError;
    if (Object.keys(e).length) { setErrors(e); return; }
    setSubmitting(true);
    try {
      await onSubmit({
        id: 0, // 저장 시 outfit_id가 부여된다
        name: title.trim(),
        style,
        img,
        height,
        weight,
        productIds,
        desc: desc.trim(),
        seasons: SEASONS.filter((s) => seasons.includes(s)),
      });
      onClose();
    } catch (err) {
      setErrors({ submit: errorMessage(err) });
      setSubmitting(false);
    }
  };

  const optionStyle = (sel: boolean, invalid = false) => ({
    background: sel ? "white" : "transparent",
    color: sel ? "#111" : "#777",
    borderColor: sel ? "white" : invalid ? "#ef4444" : "#333",
  });

  return (
    <div
      className="fixed inset-0 z-50 flex items-end md:items-center justify-center"
      style={{ fontFamily: "'Noto Sans KR', sans-serif", background: "rgba(0,0,0,0.7)" }}
    >
      <div className="absolute inset-0" onClick={onClose} />
      <div
        className="relative w-full max-w-[520px] mx-0 md:mx-4 flex flex-col shadow-2xl overflow-hidden rounded-t-xl md:rounded-xl"
        style={{ background: "#1a1917", maxHeight: "94vh" }}
      >
        {/* Header */}
        <div className="shrink-0 flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: "#2e2c2a" }}>
          <h2 className="text-white text-base font-bold">코디 올리기</h2>
          <button onClick={onClose} aria-label="닫기" className="text-white/50 hover:text-white/90 transition-colors">
            <X size={18} />
          </button>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6" style={{ scrollbarWidth: "thin" }}>

          {/* 사진 업로드 */}
          <div>
            <p className="text-[11px] font-bold tracking-[0.14em] uppercase mb-2.5" style={{ color: "#888" }}>
              사진 <span className="text-red-400">*</span>
            </p>
            {img ? (
              <div className="relative w-[76px] h-[95px] overflow-hidden" style={{ borderRadius: "6px" }}>
                <img src={img} alt="" className="w-full h-full object-cover" />
                <button
                  type="button"
                  aria-label="사진 삭제"
                  onClick={() => { setImg(""); if (fileRef.current) fileRef.current.value = ""; }}
                  className="absolute top-1 right-1 w-5 h-5 rounded-full flex items-center justify-center"
                  style={{ background: "rgba(0,0,0,0.65)" }}
                >
                  <X size={10} color="white" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                className="w-[76px] h-[95px] flex flex-col items-center justify-center gap-2 border transition-colors"
                style={{ borderRadius: "6px", borderColor: errors.img ? "#ef4444" : "#333", background: "#111" }}
                onClick={() => fileRef.current?.click()}
                onDrop={(e) => { e.preventDefault(); void attachImage(e.dataTransfer.files?.[0]); }}
                onDragOver={(e) => e.preventDefault()}
              >
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#555" strokeWidth="1.5" strokeLinecap="round">
                  <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
                  <circle cx="12" cy="13" r="4"/>
                </svg>
                <span className="text-[10px]" style={{ color: "#555" }}>추가</span>
              </button>
            )}
            {errors.img && <p className="text-xs text-red-400 mt-1.5">{errors.img}</p>}
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => void attachImage(e.target.files?.[0])} />
          </div>

          {/* 코디 제목 */}
          <div>
            <p className="text-[11px] font-bold tracking-[0.14em] uppercase mb-2" style={{ color: "#888" }}>
              코디 제목 <span className="text-red-400">*</span>
            </p>
            <input
              className="w-full px-0 py-2 text-sm text-white bg-transparent outline-none border-b transition-colors placeholder:text-white/20"
              style={{ borderColor: errors.title ? "#ef4444" : "#333" }}
              placeholder="예: 봄 오피스 데이룩"
              maxLength={40}
              value={title}
              onChange={(e) => { setTitle(e.target.value); setErrors((er) => ({ ...er, title: "" })); }}
            />
            {errors.title && <p className="text-xs text-red-400 mt-1">{errors.title}</p>}
          </div>

          {/* 체형 정보 */}
          <div>
            <p className="text-[11px] font-bold tracking-[0.14em] uppercase mb-3" style={{ color: "#888" }}>체형 정보 <span className="text-white/25 font-normal normal-case">(선택)</span></p>
            <div className="flex gap-6">
              {[
                { placeholder: "키", unit: "cm", value: height, set: setHeight, max: undefined },
                { placeholder: "몸무게", unit: "kg", value: weight, set: setWeight, max: 999 },
              ].map((f) => (
                <div key={f.unit} className="flex-1 relative">
                  <input
                    type="number"
                    min={0}
                    max={f.max}
                    aria-label={f.placeholder}
                    className="w-full px-0 pb-2 text-sm text-white bg-transparent outline-none border-b placeholder:text-white/20 pr-8"
                    style={{ borderColor: errors.body ? "#ef4444" : "#333" }}
                    placeholder={f.placeholder}
                    value={f.value}
                    onChange={(e) => { f.set(e.target.value); setErrors((er) => ({ ...er, body: "" })); }}
                  />
                  <span className="absolute right-0 bottom-2 text-xs" style={{ color: "#666" }}>{f.unit}</span>
                </div>
              ))}
            </div>
            {errors.body && <p className="text-xs text-red-400 mt-1.5">{errors.body}</p>}
          </div>

          {/* 계절 */}
          <div>
            <p className="text-[11px] font-bold tracking-[0.14em] uppercase mb-2.5" style={{ color: "#888" }}>계절 <span className="text-white/25 font-normal normal-case">(여러 개 선택 가능)</span></p>
            <div className="flex gap-2">
              {SEASONS.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setSeasons(seasons.includes(s) ? seasons.filter((x) => x !== s) : [...seasons, s])}
                  className="flex-1 py-2 text-xs font-medium transition-all border"
                  style={{ ...optionStyle(seasons.includes(s)), borderRadius: "4px" }}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* 스타일 태그 */}
          <div>
            <p className="text-[11px] font-bold tracking-[0.14em] uppercase mb-2.5" style={{ color: "#888" }}>
              스타일 <span className="text-red-400">*</span>
            </p>
            <div className="flex gap-2 flex-wrap">
              {styles.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => { setStyle(style === s ? "" : s); setErrors((er) => ({ ...er, style: "" })); }}
                  className="px-3.5 py-1.5 text-xs font-medium border transition-all"
                  style={{ ...optionStyle(style === s, !!errors.style), borderRadius: "20px" }}
                >
                  #{s}
                </button>
              ))}
            </div>
            {errors.style && <p className="text-xs text-red-400 mt-1.5">{errors.style}</p>}
          </div>

          {/* 상품 연결 */}
          <div>
            <p className="text-[11px] font-bold tracking-[0.14em] uppercase mb-1.5" style={{ color: "#888" }}>
              상품 연결 <span className="text-red-400">*</span>
              {productIds.length > 0 && <span className="text-white/60 font-normal normal-case ml-1">{productIds.length}개 선택됨</span>}
            </p>
            <p className="text-[10px] mb-2.5" style={{ color: "#555" }}>원하는 상품을 모두 고를 수 있어요. 다시 누르면 선택이 해제돼요.</p>

            {/* 선택된 상품 칩 */}
            {productIds.length > 0 && (
              <div className="flex gap-2 flex-wrap mb-3">
                {productIds.flatMap((id) => catalogProducts.find((p) => p.id === id) ?? []).map((p) => (
                  <div key={p.id} className="flex items-center gap-1.5 border pl-1 pr-2 py-1" style={{ borderColor: "#333", background: "#111", borderRadius: "4px" }}>
                    <div className="w-7 h-7 overflow-hidden shrink-0" style={{ borderRadius: "3px" }}>
                      <img src={p.img} alt="" className="w-full h-full object-cover" />
                    </div>
                    <span className="text-[11px] font-medium text-white max-w-[90px] truncate">{p.name}</span>
                    <button type="button" onClick={() => toggleProduct(p.id)} className="text-white/50 hover:text-white transition-colors ml-0.5" aria-label={`${p.name} 선택 해제`}>
                      <X size={11} />
                    </button>
                  </div>
                ))}
              </div>
            )}
            <div className="flex gap-2.5 overflow-x-auto pb-2" style={{ scrollbarWidth: "none" }}>
              {catalogProducts.map((p) => {
                const sel = productIds.includes(p.id);
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => toggleProduct(p.id)}
                    className={`shrink-0 w-[84px] text-left transition-opacity ${sel ? "opacity-100" : "opacity-60 hover:opacity-100"}`}
                  >
                    <div
                      className="relative overflow-hidden mb-1.5 border-2"
                      style={{ aspectRatio: "3/4", borderRadius: "6px", borderColor: sel ? "white" : "transparent" }}
                    >
                      <img src={p.img} alt={p.name} className="w-full h-full object-cover" />
                    </div>
                    <p className="text-[10px] font-medium text-white truncate leading-snug">{p.name}</p>
                    <p className="text-[10px]" style={{ color: "#777" }}>{getShopPrices(p)[0].price.toLocaleString()}원~</p>
                  </button>
                );
              })}
            </div>
            {errors.products && <p className="text-xs text-red-400 mt-1">{errors.products}</p>}
          </div>

          {/* 한 줄 설명 */}
          <div>
            <p className="text-[11px] font-bold tracking-[0.14em] uppercase mb-2" style={{ color: "#888" }}>한 줄 설명 <span className="text-white/25 font-normal normal-case">(선택)</span></p>
            <input
              className="w-full px-0 py-2 text-sm text-white bg-transparent outline-none border-b placeholder:text-white/20"
              style={{ borderColor: "#333" }}
              placeholder="이 코디의 포인트를 한 줄로 소개해주세요"
              maxLength={80}
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
            />
            <p className="text-[10px] text-right mt-1" style={{ color: "#444" }}>{desc.length}/80</p>
          </div>
        </div>

        {/* Footer buttons */}
        <div className="shrink-0 px-6 py-4 border-t" style={{ borderColor: "#2e2c2a" }}>
          {errors.submit && <p className="text-xs text-red-400 mb-2">{errors.submit}</p>}
          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 text-sm font-medium border transition-colors"
              style={{ color: "#888", borderColor: "#333", borderRadius: "6px" }}
            >
              취소
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={submitting}
              className="flex-[2] py-3 text-sm font-bold transition-opacity disabled:opacity-50"
              style={{ background: "white", color: "#111", borderRadius: "6px" }}
            >
              {submitting ? "업로드 중..." : "코디 올리기"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

const rangeInputClass =
  "absolute w-full h-full appearance-none bg-transparent pointer-events-none " +
  "[&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-6 [&::-webkit-slider-thumb]:h-6 [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:pointer-events-auto " +
  "[&::-moz-range-thumb]:w-6 [&::-moz-range-thumb]:h-6 [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:cursor-pointer [&::-moz-range-thumb]:pointer-events-auto";

// ─── 키/몸무게 범위 슬라이더 ──────────────────────────────────────────────────

function DualRangeSlider({
  min, max, minVal, maxVal, onMinChange, onMaxChange, unit,
}: {
  min: number; max: number; minVal: number; maxVal: number;
  onMinChange: (v: number) => void; onMaxChange: (v: number) => void;
  unit: string;
}) {
  const pct = (v: number) => ((v - min) / (max - min)) * 100;
  return (
    <div>
      <div className="flex justify-between mb-3">
        <span style={{ color: "#aaa", fontSize: 12 }}>{minVal}{unit}</span>
        <span style={{ color: "#aaa", fontSize: 12 }}>{maxVal}{unit}</span>
      </div>
      <div className="relative" style={{ height: 24 }}>
        <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-[3px]" style={{ background: "#333", borderRadius: 2 }} />
        <div
          className="absolute top-1/2 -translate-y-1/2 h-[3px]"
          style={{ left: `${pct(minVal)}%`, right: `${100 - pct(maxVal)}%`, background: "white", borderRadius: 2 }}
        />
        {[minVal, maxVal].map((v, i) => (
          <div
            key={i}
            className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full border-2 pointer-events-none"
            style={{ left: `calc(${pct(v)}% - 8px)`, borderColor: "#222", zIndex: 6 }}
          />
        ))}
        {/* 실제 입력은 투명한 range 두 개가 받는다. 겹쳐 있어서 입력 전체가 아니라 손잡이만 포인터를 받게 해야 둘 다 잡힌다.
            최솟값이 오른쪽 끝에 붙으면 위로 올려 다시 잡을 수 있게 한다. */}
        <input
          type="range" min={min} max={max} step={1} value={minVal}
          onChange={(e) => { const v = Number(e.target.value); if (v < maxVal) onMinChange(v); }}
          className={rangeInputClass}
          style={{ opacity: 0, zIndex: minVal > max - (max - min) * 0.1 ? 5 : 3, top: 0, left: 0 }}
        />
        <input
          type="range" min={min} max={max} step={1} value={maxVal}
          onChange={(e) => { const v = Number(e.target.value); if (v > minVal) onMaxChange(v); }}
          className={rangeInputClass}
          style={{ opacity: 0, zIndex: 4, top: 0, left: 0 }}
        />
      </div>
      <div className="flex justify-between mt-1">
        <span style={{ color: "#555", fontSize: 10 }}>{min}{unit}</span>
        <span style={{ color: "#555", fontSize: 10 }}>{max}{unit}</span>
      </div>
    </div>
  );
}

// ─── 코디 상세 모달 ───────────────────────────────────────────────────────────

export function OutfitDetailModal({
  item,
  catalogProducts,
  getShopPrices,
  favorited,
  onToggleFavorite,
  onOpenStyle,
  onSelectProduct,
  onClose,
}: {
  item: DailyProduct;
  catalogProducts: Product[];
  getShopPrices: (product: Product) => ShopPrice[];
  favorited: boolean;
  onToggleFavorite: () => void;
  onOpenStyle: () => void;
  onSelectProduct: (product: Product) => void;
  onClose: () => void;
}) {
  const picked = catalogProducts.filter((p) => item.productIds.includes(p.id));
  useEscapeKey(onClose);

  const tagClass = "text-[11px] px-2.5 py-1 border border-border text-muted-foreground";
  const photo = item.img || picked[0]?.img;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ fontFamily: "'Noto Sans KR', sans-serif", background: "rgba(0,0,0,0.55)" }}
      role="dialog"
      aria-modal="true"
      aria-label={item.name}
    >
      <div className="absolute inset-0" onClick={onClose} />
      <div
        className="relative w-full max-w-[960px] mx-4 bg-background text-foreground flex shadow-2xl overflow-hidden"
        style={{ height: "min(92vh, 680px)" }}
      >
        {/* ── 왼쪽: 사진 ── */}
        <div className="relative hidden md:block w-[42%] shrink-0 bg-[#f0eeea] overflow-hidden">
          {item.img ? (
            <img src={item.img} alt="코디" className="w-full h-full object-cover" />
          ) : picked.length >= 2 ? (
            <div className="w-full h-full grid grid-cols-2 gap-px bg-border">
              {picked.slice(0, 4).map((p) => (
                <div key={p.id} className="overflow-hidden bg-secondary">
                  <img src={p.img} alt="" className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          ) : picked.length === 1 ? (
            <img src={picked[0].img} alt="" className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <span className="text-muted-foreground/40 text-sm">이미지 없음</span>
            </div>
          )}
        </div>

        {/* ── 오른쪽: 내용 ── */}
        <div className="flex-1 min-w-0 flex flex-col overflow-hidden bg-background">

          {/* 헤더 */}
          <div className="shrink-0 flex items-center justify-between px-5 py-3.5 border-b border-border">
            <button type="button" onClick={onOpenStyle} className="flex items-center gap-2 hover:opacity-70 transition-opacity">
              <div className="w-7 h-7 bg-primary text-primary-foreground flex items-center justify-center font-bold text-[11px] tracking-tight shrink-0">
                D.
              </div>
              <span className="text-[13px] font-semibold">{item.style}</span>
              <ChevronRight size={14} className="text-muted-foreground" />
            </button>
            <button onClick={onClose} aria-label="닫기" className="text-muted-foreground hover:text-foreground transition-colors p-1">
              <X size={18} />
            </button>
          </div>

          {/* 스크롤 영역 */}
          <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: "thin" }}>

            {/* 모바일에서는 왼쪽 사진 칸이 없으므로 여기에 코디 사진을 보여준다. */}
            {photo && (
              <div className="md:hidden bg-[#f0eeea]" style={{ aspectRatio: "4/5" }}>
                <img src={photo} alt="코디" className="w-full h-full object-cover" />
              </div>
            )}

            {/* 카테고리 태그 + 즐겨찾기 */}
            <div className="flex items-start gap-2 px-5 pt-4 pb-3 border-b border-border">
              <div className="flex flex-wrap gap-1.5 flex-1">
                {[item.style, ...item.seasons].filter(Boolean).map((t) => (
                  <span key={t} className={tagClass} style={{ borderRadius: "20px" }}>{t}</span>
                ))}
              </div>
              <button type="button" onClick={onToggleFavorite} aria-label={favorited ? "코디 저장 취소" : "코디 저장"} aria-pressed={favorited} className="shrink-0 -m-1 p-2 transition-colors">
                <Heart size={18} className={favorited ? "fill-red-400 text-red-400" : "text-muted-foreground/50"} />
              </button>
            </div>

            {/* 신체 정보 */}
            {bodyInfo(item) && (
              <div className="px-5 py-3 border-b border-border">
                <span className="text-[12px] text-muted-foreground">모델 {bodyInfo(item)}</span>
              </div>
            )}

            {/* 이름 + 간단 설명 */}
            <div className="px-5 py-3.5 border-b border-border">
              <p className="text-[15px] font-bold leading-snug">{item.name}</p>
              {item.desc && <p className="text-[13px] text-foreground leading-relaxed mt-1.5">{item.desc}</p>}
            </div>

            <div className="px-5 py-3.5 border-b border-border">
              <OutfitFeedback outfitId={item.id} outfitName={item.name} />
            </div>

            {/* 코디 상품: 누르면 그 상품 상세로 간다 */}
            <div className="px-5 pt-4 pb-4">
              <p className="text-[13px] font-bold mb-1">코디 상품 {picked.length}개</p>

              <div className="divide-y divide-border">
                {picked.map((p) => {
                  const cheapest = getShopPrices(p)[0];
                  const discountPct = p.originalPrice ? Math.round((1 - cheapest.price / p.originalPrice) * 100) : 0;
                  const onSale = discountPct > 0;
                  return (
                    <div key={p.id} {...clickable(() => onSelectProduct(p))} className="group flex items-start gap-3 py-3.5 cursor-pointer">
                      <div className="w-[60px] h-[74px] overflow-hidden shrink-0 bg-secondary">
                        <img src={p.img} alt={p.name} className="w-full h-full object-cover" />
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 mb-1">
                          <span className="text-[10px] font-bold bg-secondary border border-border px-1.5 py-0.5 text-muted-foreground">{p.category}</span>
                        </div>
                        <p className="text-[13px] font-medium leading-snug mb-1.5 group-hover:underline underline-offset-2">{p.name}</p>
                        <div className="flex items-center gap-1.5 text-[13px] font-bold" style={onSale ? { color: "#e55c2d" } : undefined}>
                          {onSale && <span>{discountPct}%</span>}
                          <span>{cheapest.price.toLocaleString()}원</span>
                        </div>
                      </div>

                      <span
                        className="shrink-0 border border-border text-[11px] px-2.5 py-1.5 group-hover:bg-secondary transition-colors text-muted-foreground self-end mb-1"
                        style={{ borderRadius: "3px" }}
                      >
                        상품 상세보기
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── 코디 피드 섹션 ───────────────────────────────────────────────────────────

type FeedFilterPanel = "계절" | "스타일" | "키/몸무게";

const H_MIN = 150, H_MAX = 200, W_MIN = 40, W_MAX = 110;

// 더보기를 누르기 전에는 6개씩 두 줄만 보여준다.
const COLLAPSED_COUNT = 12;

export function OutfitFeedSection({
  outfits,
  styles,
  catalogProducts,
  getShopPrices,
  bookmarkedIds,
  onToggleBookmark,
  onAddOutfit,
  onSelectOutfit,
  isLoggedIn,
  onRequireLogin,
}: {
  isLoggedIn: boolean;
  onRequireLogin: () => void;
  outfits: DailyProduct[];
  styles: string[];
  catalogProducts: Product[];
  getShopPrices: (product: Product) => ShopPrice[];
  bookmarkedIds: number[];
  onToggleBookmark: (outfitId: number) => void;
  onAddOutfit: (o: DailyProduct) => Promise<void>;
  onSelectOutfit: (outfit: DailyProduct) => void;
}) {
  const [uploadOpen, setUploadOpen] = useState(false);
  const [ratings, setRatings] = useState<Record<number, number>>({});

  // ── 필터 상태 ──
  const [openPanel, setOpenPanel] = useState<FeedFilterPanel | null>(null);
  const [selSeasons, setSelSeasons] = useState<string[]>([]);
  const [selStyles, setSelStyles] = useState<string[]>([]);
  const [heightMin, setHeightMin] = useState(H_MIN);
  const [heightMax, setHeightMax] = useState(H_MAX);
  const [weightMin, setWeightMin] = useState(W_MIN);
  const [weightMax, setWeightMax] = useState(W_MAX);
  const [sortOrder, setSortOrder] = useState<"추천순" | "최신순">("추천순");
  const [expanded, setExpanded] = useState(false);

  // 추천순은 별점 평균이 높은 코디부터 보여준다.
  useEffect(() => {
    let active = true;
    Promise.all(outfits.map((o) => fetchOutfitRating(o.id))).then((results) => {
      if (active) setRatings(Object.fromEntries(outfits.map((o, i) => [o.id, results[i].average])));
    });
    return () => { active = false; };
  }, [outfits]);

  const heightActive = heightMin > H_MIN || heightMax < H_MAX;
  const weightActive = weightMin > W_MIN || weightMax < W_MAX;
  const bodyActive = heightActive || weightActive;
  const anyFilter = selSeasons.length > 0 || selStyles.length > 0 || bodyActive;

  const togglePanel = (p: FeedFilterPanel) => setOpenPanel((prev) => (prev === p ? null : p));
  const toggleArr = (arr: string[], val: string) =>
    arr.includes(val) ? arr.filter((x) => x !== val) : [...arr, val];

  const resetAll = () => {
    setSelSeasons([]); setSelStyles([]);
    setHeightMin(H_MIN); setHeightMax(H_MAX);
    setWeightMin(W_MIN); setWeightMax(W_MAX);
    setOpenPanel(null);
  };

  const inRange = (value: string, min: number, max: number) => {
    const n = parseInt(value);
    return !isNaN(n) && n >= min && n <= max;
  };

  const filtered = outfits
    .filter((o) => selSeasons.length === 0 || seasonsOf(o).some((s) => selSeasons.includes(s)))
    .filter((o) => selStyles.length === 0 || selStyles.includes(o.style))
    .filter((o) => !heightActive || inRange(o.height, heightMin, heightMax))
    .filter((o) => !weightActive || inRange(o.weight, weightMin, weightMax))
    .sort((a, b) => (sortOrder === "추천순" ? (ratings[b.id] ?? 0) - (ratings[a.id] ?? 0) : 0) || b.id - a.id);

  const hasMore = !expanded && filtered.length > COLLAPSED_COUNT;
  const visible = hasMore ? filtered.slice(0, COLLAPSED_COUNT) : filtered;

  const toggleStyle = (active: boolean, idleBorder: string) => ({
    background: active ? "white" : "transparent",
    color: active ? "#111" : "#777",
    borderColor: active ? "white" : idleBorder,
    borderRadius: "4px",
  });

  const filterButtons: { panel: FeedFilterPanel; active: boolean; badge: string | null }[] = [
    { panel: "계절", active: selSeasons.length > 0, badge: selSeasons.length > 0 ? String(selSeasons.length) : null },
    { panel: "스타일", active: selStyles.length > 0, badge: selStyles.length > 0 ? String(selStyles.length) : null },
    { panel: "키/몸무게", active: bodyActive, badge: bodyActive ? "!" : null },
  ];

  return (
    <section id="outfit-feed" style={{ background: "#141312" }} className="py-14 px-4 md:px-8 scroll-mt-16">
      {uploadOpen && isLoggedIn && (
        <OutfitFeedUploadModal
          styles={styles}
          catalogProducts={catalogProducts}
          getShopPrices={getShopPrices}
          onClose={() => setUploadOpen(false)}
          onSubmit={onAddOutfit}
        />
      )}
      <div className="max-w-[1400px] mx-auto">
        {/* 헤더 */}
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="text-[11px] tracking-[0.28em] uppercase mb-2" style={{ color: "#6b6762", fontFamily: "'DM Mono', monospace" }}>
              D.aily Looks
            </p>
            <h2 className="text-2xl md:text-3xl font-bold text-white leading-snug" style={{ fontFamily: "'Playfair Display', serif" }}>
              오늘 뭐 입지,<br className="md:hidden" /> 코디로 찾기
            </h2>
          </div>
          <button
            onClick={() => { if (isLoggedIn) setUploadOpen(true); else onRequireLogin(); }}
            className="flex items-center gap-2 text-xs font-bold px-5 py-2.5 transition-opacity hover:opacity-80 shrink-0"
            style={{ background: "white", color: "#111", borderRadius: "4px" }}
          >
            <svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M8 3v10M3 8h10" />
            </svg>
            코디 추가하기
          </button>
        </div>

        {/* ── 필터 바 ── */}
        <div className="mb-2">
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={resetAll}
              className="text-xs font-medium px-4 py-2 border transition-all"
              style={toggleStyle(!anyFilter, "#333")}
            >
              전체
            </button>

            {filterButtons.map(({ panel, active, badge }) => (
              <button
                key={panel}
                onClick={() => togglePanel(panel)}
                className="flex items-center gap-1.5 text-xs font-medium px-4 py-2 border transition-all"
                style={toggleStyle(active || openPanel === panel, "#333")}
              >
                {panel}
                {badge && (
                  <span className="w-4 h-4 rounded-full text-[10px] font-bold flex items-center justify-center" style={{ background: "#222", color: "white" }}>
                    {badge}
                  </span>
                )}
                <svg viewBox="0 0 10 6" width="9" height="6" fill="none">
                  <path d={openPanel === panel ? "M1 5l4-4 4 4" : "M1 1l4 4 4-4"} stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            ))}
          </div>

          {/* 확장 패널 */}
          {openPanel && (
            <div className="mt-2 p-4 border" style={{ borderColor: "#2e2c2a", background: "#1a1917", borderRadius: "6px" }}>
              {openPanel === "계절" && (
                <div className="flex gap-2">
                  {SEASONS.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setSelSeasons(toggleArr(selSeasons, s))}
                      className="px-5 py-2 text-xs font-medium border transition-all"
                      style={toggleStyle(selSeasons.includes(s), "#444")}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}

              {openPanel === "스타일" && (
                <div className="flex gap-2 flex-wrap">
                  {styles.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setSelStyles(toggleArr(selStyles, s))}
                      className="px-4 py-2 text-xs font-medium border transition-all"
                      style={toggleStyle(selStyles.includes(s), "#444")}
                    >
                      #{s}
                    </button>
                  ))}
                </div>
              )}

              {openPanel === "키/몸무게" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <p className="text-[11px] font-bold tracking-[0.12em] uppercase mb-3" style={{ color: "#666" }}>키 (cm)</p>
                    <DualRangeSlider
                      min={H_MIN} max={H_MAX} minVal={heightMin} maxVal={heightMax}
                      onMinChange={setHeightMin} onMaxChange={setHeightMax} unit="cm"
                    />
                  </div>
                  <div>
                    <p className="text-[11px] font-bold tracking-[0.12em] uppercase mb-3" style={{ color: "#666" }}>몸무게 (kg)</p>
                    <DualRangeSlider
                      min={W_MIN} max={W_MAX} minVal={weightMin} maxVal={weightMax}
                      onMinChange={setWeightMin} onMaxChange={setWeightMax} unit="kg"
                    />
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* ── 정렬 + 결과 수 ── */}
        <div className="flex items-center justify-between mb-6 pt-3">
          <p style={{ color: "#555", fontSize: 12 }}>{filtered.length}개 코디</p>
          <div className="flex items-center border" style={{ borderColor: "#2e2c2a", borderRadius: "4px", overflow: "hidden" }}>
            {(["추천순", "최신순"] as const).map((s, i) => (
              <button
                key={s}
                type="button"
                onClick={() => setSortOrder(s)}
                className="px-4 py-1.5 text-xs font-medium transition-all"
                style={{
                  background: sortOrder === s ? "white" : "transparent",
                  color: sortOrder === s ? "#111" : "#666",
                  borderRight: i === 0 ? "1px solid #2e2c2a" : undefined,
                }}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* ── 코디 그리드 ── */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {visible.map((item) => {
            const pickedItems = catalogProducts.filter((p) => item.productIds.includes(p.id));
            const saved = bookmarkedIds.includes(item.id);

            return (
              <div key={item.id} className="group cursor-pointer" {...clickable(() => onSelectOutfit(item))}>
                {/* 썸네일 */}
                <div className="relative overflow-hidden mb-3" style={{ borderRadius: "8px", aspectRatio: "3/4" }}>
                  {item.img ? (
                    <img src={item.img} alt={item.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.04]" />
                  ) : pickedItems.length >= 2 ? (
                    <div className="w-full h-full grid grid-cols-2 gap-px" style={{ background: "#222" }}>
                      {pickedItems.slice(0, 4).map((p) => (
                        <div key={p.id} className="overflow-hidden bg-[#1a1917]">
                          <img src={p.img} alt="" className="w-full h-full object-cover" />
                        </div>
                      ))}
                    </div>
                  ) : pickedItems.length === 1 ? (
                    <img src={pickedItems[0].img} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center" style={{ background: "#1e1c1a" }}>
                      <span className="text-white/20 text-xs">이미지 없음</span>
                    </div>
                  )}

                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

                  {/* 스타일 뱃지 */}
                  {item.style && (
                    <span className="absolute top-3 left-3 text-[9px] font-bold tracking-widest px-2 py-0.5 uppercase" style={{ background: "rgba(255,255,255,0.12)", color: "rgba(255,255,255,0.8)", backdropFilter: "blur(4px)", borderRadius: "3px" }}>
                      {item.style}
                    </span>
                  )}

                  {/* 코디 저장 */}
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); onToggleBookmark(item.id); }}
                    className="absolute top-1 right-1 p-2.5 opacity-80 hover:opacity-100 transition-opacity"
                    aria-label={saved ? `${item.name} 저장 취소` : `${item.name} 저장`}
                    aria-pressed={saved}
                  >
                    <Heart size={16} className={saved ? "fill-red-400 text-red-400" : "text-white"} />
                  </button>

                  {/* 계절 뱃지 */}
                  {item.seasons.length > 0 && (
                    <div className="absolute bottom-3 left-3 flex gap-1">
                      {item.seasons.map((s) => (
                        <span key={s} className="text-[9px] font-bold px-1.5 py-0.5" style={{ background: "rgba(0,0,0,0.55)", color: "rgba(255,255,255,0.7)", backdropFilter: "blur(4px)", borderRadius: "3px" }}>
                          {s}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* 텍스트 */}
                <p className="text-sm font-semibold text-white leading-snug mb-1 group-hover:text-white/80 transition-colors">
                  {item.name}
                </p>
                <p className="text-[11px]" style={{ color: "#5a5754" }}>
                  {pickedItems.length > 0 ? `구성 ${pickedItems.length}개` : "코디 보기"}
                  {bodyInfo(item) && <span className="ml-2">{bodyInfo(item)}</span>}
                </p>
              </div>
            );
          })}
        </div>

        {filtered.length > COLLAPSED_COUNT && (
          <div className="flex justify-center mt-8">
            <button
              type="button"
              onClick={() => setExpanded(!expanded)}
              className="text-xs font-medium px-10 py-3 border border-[#333] text-[#aaa] hover:border-white hover:text-white transition-colors"
              style={{ borderRadius: "4px" }}
            >
              {expanded ? "접기" : "더보기"}
            </button>
          </div>
        )}

        {filtered.length === 0 && (
          <div className="flex flex-col items-center py-16 gap-3">
            <p className="text-white/30 text-sm">조건에 맞는 코디가 없습니다</p>
            <button onClick={resetAll} className="text-xs underline underline-offset-2" style={{ color: "#666" }}>필터 초기화</button>
          </div>
        )}
      </div>
    </section>
  );
}
