// DB row와 화면에서 쓰는 타입 사이의 변환

import type { DailyProduct, Outfit, OutfitItem, Product } from "../../app/App";
import type { OutfitCategoryRow, OutfitRow } from "./db";

// 코디에 연결된 상품은 개수 제한 없이 product_ids에 담긴다. 역할 라벨은 상품 카테고리를 그대로 쓴다.
function outfitItems(row: OutfitRow, products: Product[]): OutfitItem[] {
  return row.product_ids.map((productId) => ({
    productId,
    role: products.find((p) => p.id === productId)?.category ?? "",
  }));
}

const categoryName = (row: OutfitRow, categories: OutfitCategoryRow[]) =>
  categories.find((c) => c.outfit_category_id === row.outfit_category_id)?.outfit_category_name ?? "";

export function toOutfit(row: OutfitRow, categories: OutfitCategoryRow[], products: Product[]): Outfit {
  const items = outfitItems(row, products);
  return {
    id: row.outfit_id,
    style: categoryName(row, categories),
    title: row.outfit_name,
    tags: row.tags,
    img: row.outfit_image || (products.find((p) => p.id === items[0]?.productId)?.img ?? ""),
    season: row.seasons.join(" · "),
    stylistNote: row.outfit_description,
    items,
  };
}

export function toDailyProduct(row: OutfitRow, categories: OutfitCategoryRow[]): DailyProduct {
  return {
    id: row.outfit_id,
    name: row.outfit_name,
    style: categoryName(row, categories),
    img: row.outfit_image,
    height: row.height,
    weight: row.weight,
    productIds: row.product_ids,
    desc: row.outfit_description,
    seasons: row.seasons,
  };
}
