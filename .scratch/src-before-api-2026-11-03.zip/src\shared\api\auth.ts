import { now, nextId, saveTable, table, type UserRow } from "./db";
import { ApiError, getSessionUserId, remove, requireSessionUserId, write } from "./storage";

export type SocialProvider = "kakao" | "google";

export type User = Omit<UserRow, "password">;

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PASSWORD_PATTERN = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/;

const normalizeEmail = (email: string) => email.trim().toLowerCase();

function toUser(row: UserRow): User {
  const { password: _password, ...user } = row;
  void _password;
  return user;
}

async function hashPassword(password: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(password));
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
}

function startSession(row: UserRow): User {
  write("db:session", row.user_id);
  return toUser(row);
}

function requireCurrentUser(users: UserRow[]): UserRow {
  const userId = requireSessionUserId();
  const current = users.find((u) => u.user_id === userId);
  if (!current) throw new ApiError("로그인이 필요합니다.");
  return current;
}

function insertUser(users: UserRow[], input: Pick<UserRow, "username" | "email" | "password">): UserRow {
  const row: UserRow = {
    user_id: nextId(users, (u) => u.user_id),
    ...input,
    role: "user",
    // 이메일 인증 메일은 백엔드 연결 후 발송한다.
    is_verified: false,
    created_at: now(),
    updated_at: now(),
    profile_image: null,
  };
  saveTable("users", [...users, row]);
  return row;
}

export async function getSession(): Promise<User | null> {
  const current = table("users").find((u) => u.user_id === getSessionUserId());
  return current ? toUser(current) : null;
}

export async function signUp(input: { name: string; email: string; password: string }): Promise<User> {
  const username = input.name.trim();
  const email = normalizeEmail(input.email);
  if (!username) throw new ApiError("이름을 입력해주세요.");
  if (!EMAIL_PATTERN.test(email)) throw new ApiError("올바른 이메일 주소를 입력해주세요.");
  if (!PASSWORD_PATTERN.test(input.password)) throw new ApiError("비밀번호는 영문, 숫자를 포함해 8자 이상이어야 합니다.");

  const users = table("users");
  if (users.some((u) => u.email === email)) throw new ApiError("이미 가입된 이메일입니다.");

  return startSession(insertUser(users, { username, email, password: await hashPassword(input.password) }));
}

export async function signIn(email: string, password: string): Promise<User> {
  const row = table("users").find((u) => u.email === normalizeEmail(email));
  if (!row || !row.password || row.password !== (await hashPassword(password))) {
    throw new ApiError("이메일 또는 비밀번호가 올바르지 않습니다.");
  }
  return startSession(row);
}

// 실제 OAuth는 백엔드가 필요하다. 지금은 제공자별 데모 계정으로 로그인시킨다.
export async function signInWithSocial(provider: SocialProvider): Promise<User> {
  const users = table("users");
  const email = `${provider}-user@daily.kr`;
  const row = users.find((u) => u.email === email) ?? insertUser(users, { username: "D.aily 회원", email, password: "" });
  return startSession(row);
}

export async function signOut(): Promise<void> {
  remove("db:session");
}

// 메일 발송은 백엔드 연결 후 구현한다. 가입 여부가 드러나지 않도록 항상 성공으로 응답한다.
export async function requestPasswordReset(email: string): Promise<void> {
  if (!EMAIL_PATTERN.test(normalizeEmail(email))) throw new ApiError("올바른 이메일 주소를 입력해주세요.");
}

export async function updateProfile(input: { name: string; email: string; avatarUrl: string | null }): Promise<User> {
  const users = table("users");
  const current = requireCurrentUser(users);
  const username = input.name.trim();
  const email = normalizeEmail(input.email);
  if (!username) throw new ApiError("닉네임을 입력해주세요.");
  if (!EMAIL_PATTERN.test(email)) throw new ApiError("올바른 이메일 주소를 입력해주세요.");
  if (users.some((u) => u.user_id !== current.user_id && u.email === email)) throw new ApiError("이미 사용 중인 이메일입니다.");

  const updated: UserRow = { ...current, username, email, profile_image: input.avatarUrl, updated_at: now() };
  saveTable("users", users.map((u) => (u.user_id === current.user_id ? updated : u)));
  return toUser(updated);
}

export async function changePassword(currentPassword: string, nextPassword: string): Promise<void> {
  const users = table("users");
  const current = requireCurrentUser(users);
  if (!current.password) throw new ApiError("소셜 로그인 계정은 비밀번호를 변경할 수 없습니다.");
  if (current.password !== (await hashPassword(currentPassword))) throw new ApiError("현재 비밀번호가 일치하지 않습니다.");
  if (!PASSWORD_PATTERN.test(nextPassword)) throw new ApiError("비밀번호는 영문, 숫자를 포함해 8자 이상이어야 합니다.");

  const password = await hashPassword(nextPassword);
  saveTable("users", users.map((u) => (u.user_id === current.user_id ? { ...u, password, updated_at: now() } : u)));
}

export async function deleteAccount(): Promise<void> {
  const users = table("users");
  const { user_id } = requireCurrentUser(users);
  saveTable("users", users.filter((u) => u.user_id !== user_id));
  saveTable("product_bookmarks", table("product_bookmarks").filter((r) => r.user_id !== user_id));
  saveTable("product_histories", table("product_histories").filter((r) => r.user_id !== user_id));
  saveTable("outfit_bookmarks", table("outfit_bookmarks").filter((r) => r.bookmark_user_id !== user_id));
  saveTable("outfit_stars", table("outfit_stars").filter((r) => r.evaluator !== user_id));
  saveTable("outfits", table("outfits").filter((r) => r.user_id !== user_id));
  saveTable("reports", table("reports").filter((r) => r.reporter_id !== user_id));
  remove(`notifications:${user_id}`);
  remove("db:session");
}
