// 백엔드가 붙기 전까지 localStorage를 서버 대신 사용한다.
// api 폴더의 함수들은 모두 Promise를 반환하므로, 나중에 내부 구현만 fetch 호출로 바꾸면 된다.

const PREFIX = "daily:";

// status는 실제 서버가 돌려줄 HTTP 상태 코드다. 401: 로그인 필요, 403: 권한 없음, 404: 대상 없음
export class ApiError extends Error {
  status: number;

  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

export function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function write(key: string, value: unknown) {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    throw new ApiError("저장 공간이 부족해 저장하지 못했습니다.");
  }
}

export function remove(key: string) {
  localStorage.removeItem(PREFIX + key);
}

export function getSessionUserId(): number | null {
  return read<number | null>("db:session", null);
}

export function requireSessionUserId(): number {
  const userId = getSessionUserId();
  if (userId === null) throw new ApiError("로그인이 필요합니다.", 401);
  return userId;
}

export function errorMessage(error: unknown): string {
  return error instanceof ApiError ? error.message : "일시적인 오류가 발생했습니다. 잠시 후 다시 시도해주세요.";
}
