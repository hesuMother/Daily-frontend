// ERD(dbdiagram)를 그대로 옮긴 목 DB. 테이블은 localStorage에 저장되고, 처음에는 아래 시드 데이터로 채워진다.
// "ERD에 없음"이라고 표시한 컬럼은 현재 화면을 유지하려고 목에만 추가한 것이므로 백엔드와 맞춰야 한다.

import { read, write } from "./storage";

// ─── Row types ───────────────────────────────────────────────────────────────

export interface UserRow {
  user_id: number;
  username: string;
  password: string; // SHA-256 해시. 빈 문자열이면 비밀번호 로그인 불가(소셜 데모·시드 계정)
  email: string;
  role: "user" | "admin";
  is_verified: boolean; // ERD 표기는 is_verfied
  created_at: string;
  updated_at: string;
  profile_image: string | null; // ERD에 없음
}

export interface CategoryRow {
  category_id: number;
  category_name: string;
  created_at: string;
}

export interface OutfitCategoryRow {
  outfit_category_id: number;
  outfit_category_name: string;
  created_at: string;
}

export interface OutfitRow {
  outfit_id: number;
  outfit_name: string;
  outfit_description: string;
  outfit_category_id: number;
  // ERD의 shirt·pants·shoes·ext 고정 컬럼 대신 상품 ID 배열로 저장한다. 같은 카테고리 상품도 여러 개 담을 수 있다.
  product_ids: number[];
  user_id: number | null; // 작성자. ERD에 없음. 시드 코디는 null
  updated_at: string;
  created_at: string;
  // ERD에 없음
  outfit_image: string;
  height: string;
  weight: string;
  seasons: string[];
  tags: string[];
}

export interface OutfitStarRow {
  star_id: number;
  stars: number;
  outfit_id: number;
  evaluator: number;
  updated_at: string;
  created_at: string;
}

export interface OutfitBookmarkRow {
  outfit_bookmark_id: number;
  outfit_id: number;
  bookmark_user_id: number;
  is_deleted: boolean;
  created_at: string;
}

export interface ProductBookmarkRow {
  product_bookmark_id: number;
  user_id: number; // ERD에 없음. 없으면 누구의 찜인지 구분할 수 없다
  product_bookmark_product_name: string; // ERD 표기는 proudct_bokmark_product_name (integer)
  product_bookmark_product_link: string; // ERD 표기는 proudct_bookmark_product_link
  is_deleted: boolean;
  created_at: string;
}

export interface ProductHistoryRow {
  product_id: number; // ERD상 PK 이름. 상품 ID가 아니라 기록 ID다
  user_id: number;
  product_link: string;
  is_deleted: boolean;
  created_at: string;
}

export interface ReportCategoryRow {
  report_category_id: number;
  report_category_name: string;
  created_at: string;
}

export interface ReportRow {
  report_id: number;
  reason: string;
  description: string;
  report_category_id: number;
  reporter_id: number;
  complete: boolean;
  completed_at: string | null;
  created_at: string;
}

interface Tables {
  users: UserRow[];
  categories: CategoryRow[];
  outfit_categories: OutfitCategoryRow[];
  outfits: OutfitRow[];
  outfit_stars: OutfitStarRow[];
  outfit_bookmarks: OutfitBookmarkRow[];
  product_bookmarks: ProductBookmarkRow[];
  product_histories: ProductHistoryRow[];
  report_categories: ReportCategoryRow[];
  reports: ReportRow[];
}

// ─── 상품 링크 ────────────────────────────────────────────────────────────────

// ERD에 products 테이블이 없어 상품은 링크로만 참조한다.
export const productLink = (productId: number) => `https://daily.kr/products/${productId}`;

export function productIdFromLink(link: string | null): number | null {
  const match = link?.match(/\/products\/(\d+)$/);
  return match ? Number(match[1]) : null;
}

// ─── Seed ────────────────────────────────────────────────────────────────────

const SEED_AT = "2026-09-01T00:00:00.000Z";

const unsplash = (photo: string) => `https://images.unsplash.com/photo-${photo}?w=700&h=950&fit=crop&auto=format`;

function seedOutfit(
  outfit_id: number, outfit_category_id: number, outfit_name: string, outfit_description: string,
  items: { shirt?: number; pants?: number; ext?: number }, photo: string, season: string, tags: string[],
): OutfitRow {
  return {
    outfit_id, outfit_name, outfit_description, outfit_category_id,
    product_ids: [items.shirt, items.pants, items.ext].flatMap((productId) => productId ?? []),
    user_id: null,
    updated_at: SEED_AT, created_at: SEED_AT,
    outfit_image: unsplash(photo), height: "", weight: "", seasons: [season], tags,
  };
}

const seedUser = (user_id: number, username: string, email: string, role: UserRow["role"], password = ""): UserRow => ({
  user_id, username, password, email, role, is_verified: true, created_at: SEED_AT, updated_at: SEED_AT, profile_image: null,
});

const named = <K extends string, V extends string>(idKey: K, nameKey: V, names: string[]) =>
  names.map((name, i) => ({ [idKey]: i + 1, [nameKey]: name, created_at: SEED_AT })) as (Record<K, number> & Record<V, string> & { created_at: string })[];

const seedOutfits: OutfitRow[] = [
  seedOutfit(1, 1, "여유로운 린넨 데일리룩", "린넨 셔츠의 자연스러운 구김과 와이드 데님의 조합. 여름 일상에 최적화된 편안한 무드로, 슬리퍼나 샌들을 더하면 완성됩니다.", { shirt: 1, pants: 2 }, "1488161628813-04466f872be2", "SS", ["오버핏", "린넨", "내추럴"]),
  seedOutfit(2, 1, "크루넥 슬랙스 세미캐주얼", "스웨트셔츠를 슬랙스와 매치해 캐주얼하지만 정돈된 인상을 줍니다. 출퇴근이나 캐주얼 미팅에 두루 활용 가능한 조합입니다.", { shirt: 4, pants: 5 }, "1519085360753-af0119f7cbe7", "FW", ["세미캐주얼", "무드있는", "데이트룩"]),
  seedOutfit(3, 1, "헤비 티셔츠 린넨 팬츠 여름룩", "두툼한 코튼 티셔츠와 리넨 팬츠의 소재 대비가 포인트. 둘 다 통기성이 좋아 더운 날씨에도 쾌적하게 입을 수 있습니다.", { shirt: 8, pants: 7 }, "1490481651871-ab68de25d43d", "SS", ["여름룩", "서머", "라이트"]),
  seedOutfit(4, 2, "바시티 재킷 데님 스트릿룩", "커버낫 바시티 재킷과 와이드 데님의 클래식 조합. 올드스쿨 무드를 살리면서도 와이드 실루엣으로 현대적인 핏을 완성합니다.", { ext: 6, pants: 2 }, "1529139574466-a303027614b", "FW", ["바시티", "아카이브", "그래픽"]),
  seedOutfit(5, 2, "크루넥 데님 스케이트 무드", "볼드한 크루넥 스웨트셔츠를 와이드 데님과 매치. 오버사이즈 핏을 활용해 스트릿 감성을 극대화할 수 있습니다.", { shirt: 4, pants: 2 }, "1523398002811-999ca8dec234", "AW", ["스케이트", "루즈핏", "하이틴"]),
  seedOutfit(6, 2, "헤비 티셔츠 오버핏 빈티지룩", "260g 두께의 헤비 티셔츠를 크게 입어 빈티지 감성 연출. 데님과 매치하면 90년대 스트릿 무드가 자연스럽게 완성됩니다.", { shirt: 8, pants: 2 }, "1556821840-3a63f15732ce", "SS", ["빈티지", "오버핏", "미국무드"]),
  seedOutfit(7, 3, "울 코트 슬랙스 시크 오피스룩", "아더에러 울 코트를 테일러드 슬랙스와 매치한 완성도 높은 비즈니스 룩. 중요한 미팅이나 프레젠테이션에 자신감을 더해줍니다.", { ext: 3, pants: 5 }, "1573496359142-b8d87734a5a2", "FW", ["비즈니스", "럭셔리", "시크"]),
  seedOutfit(8, 3, "린넨 셔츠 슬랙스 스마트 캐주얼", "린넨 셔츠를 슬랙스에 살짝 넣거나 내추럴하게 아웃하여 스마트 캐주얼 완성. 사무실부터 팀 회식까지 활용도가 높은 조합입니다.", { shirt: 1, pants: 5 }, "1600275669439-14e40452d20b", "SS", ["스마트캐주얼", "비즈니스캐주얼", "클린"]),
  seedOutfit(9, 4, "울 코트 린넨 팬츠 모던 미니멀", "아더에러의 울 코트와 리넨 와이드 팬츠의 드레이프 대비가 아름다운 조합. 컬러를 오트밀이나 블랙으로 통일하면 더욱 세련됩니다.", { ext: 3, pants: 7 }, "1485968579580-b6d095142e6e", "FW", ["무채색", "드레이프", "모던"]),
  seedOutfit(10, 4, "헤비 티 슬랙스 화이트 미니멀", "흰색 헤비 코튼 티셔츠와 블랙 슬랙스의 가장 완결된 미니멀 공식. 불필요한 디테일을 모두 걷어낸 본질에 충실한 스타일링입니다.", { shirt: 8, pants: 5 }, "1509631179647-0177331693ae", "SS", ["화이트톤", "베이직", "에센셜"]),
  seedOutfit(11, 5, "크루넥 데님 스포티 캐주얼", "스웨트셔츠를 데님과 매치한 캠퍼스 무드. 스니커즈와 함께하면 스포티한 에너지를 자연스럽게 표현할 수 있습니다.", { shirt: 4, pants: 2 }, "1483721310020-03333e577078", "AW", ["애슬레저", "스포티", "캠퍼스"]),
  seedOutfit(12, 5, "헤비 티 리넨 팬츠 활동적 이지룩", "카키나 그레이 헤비 티셔츠에 리넨 팬츠를 매치한 이지 스포티룩. 편안하면서도 정돈된 느낌으로 주말 액티비티에 적합합니다.", { shirt: 8, pants: 7 }, "1542291026-7eec264c27ff", "SS", ["이지웨어", "릴렉스핏", "애슬레저"]),
];

const seedEvaluators = [2, 3, 4];

const seed: Tables = {
  users: [
    // 관리자 로그인: admin@daily.kr / admin1234
    seedUser(1, "관리자", "admin@daily.kr", "admin", "ac9689e2272427085e35b9d3e3e8bed88cb3434828b43b86fc0596cad4c6e270"),
    seedUser(2, "민지", "minji@daily.kr", "user"),
    seedUser(3, "준호", "junho@daily.kr", "user"),
    seedUser(4, "서연", "seoyeon@daily.kr", "user"),
  ],
  categories: named("category_id", "category_name", ["상의", "하의", "아우터"]),
  outfit_categories: named("outfit_category_id", "outfit_category_name", ["캐주얼", "스트릿", "오피스룩", "미니멀", "스포티"]),
  outfits: seedOutfits,
  outfit_stars: seedOutfits.flatMap((outfit) =>
    seedEvaluators.map((evaluator, i) => ({
      star_id: (outfit.outfit_id - 1) * seedEvaluators.length + i + 1,
      stars: 3 + ((outfit.outfit_id * evaluator) % 3),
      outfit_id: outfit.outfit_id,
      evaluator,
      updated_at: SEED_AT,
      created_at: SEED_AT,
    })),
  ),
  outfit_bookmarks: [],
  product_bookmarks: [],
  product_histories: [],
  report_categories: named("report_category_id", "report_category_name", ["부적절한 콘텐츠", "허위·과장 정보", "저작권 침해", "스팸·광고", "기타"]),
  reports: [
    {
      report_id: 1,
      reason: "상품 정보가 실제와 다릅니다",
      description: "[코디 #4 바시티 재킷 데님 스트릿룩] 연결된 상품과 사진 속 옷이 다릅니다.",
      report_category_id: 2,
      reporter_id: 2,
      complete: false,
      completed_at: null,
      created_at: SEED_AT,
    },
  ],
};

// ─── Table access ────────────────────────────────────────────────────────────

export function table<K extends keyof Tables>(name: K): Tables[K] {
  return read(`db:${name}`, seed[name]);
}

export function saveTable<K extends keyof Tables>(name: K, rows: Tables[K]) {
  write(`db:${name}`, rows);
}

export function nextId<T>(rows: T[], id: (row: T) => number): number {
  return rows.reduce((max, row) => Math.max(max, id(row)), 0) + 1;
}

export const now = () => new Date().toISOString();
