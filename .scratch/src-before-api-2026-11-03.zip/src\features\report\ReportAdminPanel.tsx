import { useEffect, useState } from "react";
import { completeReport, fetchReports, type ReportView } from "../../shared/api/reports";
import { errorMessage } from "../../shared/api/storage";

const formatDate = (iso: string) => new Date(iso).toLocaleDateString("ko-KR");

export function ReportAdminPanel() {
  const [reports, setReports] = useState<ReportView[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    fetchReports()
      .then((rows) => { if (active) setReports(rows); })
      .catch((err) => { if (active) setError(errorMessage(err)); });
    return () => { active = false; };
  }, []);

  const handleComplete = async (reportId: number) => {
    try {
      await completeReport(reportId);
      setReports(await fetchReports());
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  if (error) return <p className="text-[13px] text-[#b34b42]">{error}</p>;
  if (reports.length === 0) return <p className="text-[14px] text-[#8c857d]">접수된 신고가 없습니다.</p>;

  return (
    <div className="max-w-[720px] space-y-2">
      {reports.map((report) => (
        <div key={report.report_id} className="border border-[#dedbd6] bg-white px-4 py-4">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="mb-1.5 flex items-center gap-2">
                <span className="bg-[#efede9] px-2 py-0.5 text-[10px] font-bold text-[#8c857d]">{report.report_category_name}</span>
                <span className={`text-[10px] font-bold ${report.complete ? "text-[#3f7a4d]" : "text-[#b34b42]"}`}>
                  {report.complete ? "처리 완료" : "미처리"}
                </span>
              </div>
              <p className="text-[14px] font-medium text-[#171615]">{report.reason}</p>
              {report.description && <p className="mt-1 text-[12px] leading-relaxed text-[#5c564f]">{report.description}</p>}
              <p className="mt-2 text-[11px] text-[#8c857d]">
                {report.reporter_username} · {formatDate(report.created_at)}
                {report.completed_at && ` · ${formatDate(report.completed_at)} 처리`}
              </p>
            </div>
            {!report.complete && (
              <button
                type="button"
                onClick={() => handleComplete(report.report_id)}
                className="shrink-0 border border-[#dedbd6] px-3 py-2 text-[12px] font-medium text-[#171615] transition-colors hover:border-[#171615]"
              >
                처리 완료
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
