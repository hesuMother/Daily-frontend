import { now, nextId, productIdFromLink, saveTable, table, type OutfitCategoryRow, type OutfitRow } from "./db";
import { ApiError, getSessionUserId, requireSessionUserId } from "./storage";

export type OutfitInput = Omit<OutfitRow, "outfit_id" | "user_id" | "created_at" | "updated_at" | "tags">;

// 예전에는 상품을 shirt·pants·shoes·ext 고정 컬럼에 하나씩 담았다.
// localStorage에 그 구조로 남아 있는 코디는 product_ids 배열로 바꿔서 읽는다.
const LEGACY_LINK_COLUMNS = ["shirt_link", "pants_link", "shoes_link", "ext_link"];

function outfitRows(): OutfitRow[] {
  return table("outfits").map((row) => {
    if (Array.isArray(row.product_ids)) return row;
    const legacy = row as unknown as Record<string, string | null | undefined>;
    return {
      ...row,
      product_ids: LEGACY_LINK_COLUMNS.flatMap((column) => productIdFromLink(legacy[column] ?? null) ?? []),
      user_id: null,
    };
  });
}

export interface OutfitRating {
  average: number;
  count: number;
  myStars: number | null;
}

// ─── outfit_categories / outfits ─────────────────────────────────────────────

export async function fetchOutfitCategories(): Promise<OutfitCategoryRow[]> {
  return table("outfit_categories");
}

export async function fetchOutfits(): Promise<OutfitRow[]> {
  return outfitRows();
}

// 키·몸무게는 선택 입력이다. 입력했다면 키는 0 이상, 몸무게는 0 이상 1000kg 미만이어야 한다.
// 문제가 있으면 안내 문구를, 없으면 null을 돌려준다. 업로드 화면과 createOutfit이 같이 쓴다.
export function bodyInfoError(height: string, weight: string): string | null {
  if (height !== "" && !(Number(height) >= 0)) return "키는 0 이상으로 입력해주세요.";
  if (weight !== "" && !(Number(weight) >= 0 && Number(weight) < 1000)) return "몸무게는 0 이상 1000kg 미만으로 입력해주세요.";
  return null;
}

// 코디 업로드는 회원 전용이다. 비회원 요청은 401로 거부하고, 작성자는 세션의 user_id로 저장한다.
export async function createOutfit(input: OutfitInput): Promise<OutfitRow> {
  const user_id = requireSessionUserId();
  const outfit_name = input.outfit_name.trim();
  const product_ids = [...new Set(input.product_ids)];
  if (!outfit_name) throw new ApiError("코디 이름을 입력해주세요.");
  if (product_ids.length === 0) throw new ApiError("상품을 1개 이상 선택해주세요.");
  const bodyError = bodyInfoError(input.height, input.weight);
  if (bodyError) throw new ApiError(bodyError);

  const rows = outfitRows();
  const row: OutfitRow = {
    ...input,
    outfit_name,
    product_ids,
    user_id,
    outfit_id: nextId(rows, (r) => r.outfit_id),
    tags: [],
    created_at: now(),
    updated_at: now(),
  };
  saveTable("outfits", [...rows, row]);
  return row;
}

// 본인이 올린 코디만 삭제할 수 있다. 남의 코디면 403으로 거부한다.
export async function deleteOutfit(outfitId: number): Promise<void> {
  const userId = requireSessionUserId();
  const rows = outfitRows();
  const target = rows.find((r) => r.outfit_id === outfitId);
  if (!target) throw new ApiError("코디를 찾을 수 없습니다.", 404);
  if (target.user_id !== userId) throw new ApiError("본인이 올린 코디만 삭제할 수 있습니다.", 403);

  saveTable("outfits", rows.filter((r) => r.outfit_id !== outfitId));
  saveTable("outfit_stars", table("outfit_stars").filter((r) => r.outfit_id !== outfitId));
  saveTable("outfit_bookmarks", table("outfit_bookmarks").filter((r) => r.outfit_id !== outfitId));
}

// ─── outfit_stars (별점) ──────────────────────────────────────────────────────

export async function fetchOutfitRating(outfitId: number): Promise<OutfitRating> {
  const userId = getSessionUserId();
  const rows = table("outfit_stars").filter((r) => r.outfit_id === outfitId);
  const total = rows.reduce((sum, r) => sum + r.stars, 0);
  return {
    average: rows.length ? total / rows.length : 0,
    count: rows.length,
    myStars: rows.find((r) => r.evaluator === userId)?.stars ?? null,
  };
}

// 한 사람은 코디당 별점 하나만 가진다. 다시 매기면 기존 별점을 수정한다.
export async function rateOutfit(outfitId: number, stars: number): Promise<OutfitRating> {
  const userId = requireSessionUserId();
  if (!Number.isInteger(stars) || stars < 1 || stars > 5) throw new ApiError("별점은 1점부터 5점까지 줄 수 있습니다.");

  const rows = table("outfit_stars");
  const existing = rows.find((r) => r.outfit_id === outfitId && r.evaluator === userId);
  saveTable("outfit_stars", existing
    ? rows.map((r) => (r === existing ? { ...r, stars, updated_at: now() } : r))
    : [...rows, { star_id: nextId(rows, (r) => r.star_id), stars, outfit_id: outfitId, evaluator: userId, updated_at: now(), created_at: now() }]);
  return fetchOutfitRating(outfitId);
}

// ─── outfit_bookmarks (코디 저장) ─────────────────────────────────────────────

// 저장한 코디의 ID 목록. 비회원이면 빈 목록이다.
export async function fetchOutfitBookmarks(): Promise<number[]> {
  const userId = getSessionUserId();
  return table("outfit_bookmarks")
    .filter((r) => r.bookmark_user_id === userId && !r.is_deleted)
    .map((r) => r.outfit_id);
}

// 저장 상태를 뒤집고, 바뀐 뒤의 저장 여부를 돌려준다.
export async function toggleOutfitBookmark(outfitId: number): Promise<boolean> {
  const userId = requireSessionUserId();
  const rows = table("outfit_bookmarks");
  const existing = rows.find((r) => r.bookmark_user_id === userId && !r.is_deleted && r.outfit_id === outfitId);
  if (existing) {
    saveTable("outfit_bookmarks", rows.map((r) => (r === existing ? { ...r, is_deleted: true } : r)));
    return false;
  }
  saveTable("outfit_bookmarks", [...rows, {
    outfit_bookmark_id: nextId(rows, (r) => r.outfit_bookmark_id),
    outfit_id: outfitId,
    bookmark_user_id: userId,
    is_deleted: false,
    created_at: now(),
  }]);
  return true;
}
